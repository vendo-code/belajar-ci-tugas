<?= $this->extend('layout') ?>
<?php $this->section('content') ?>
ini halaman contact
<?php $this->endSection() ?>