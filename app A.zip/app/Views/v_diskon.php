<h3>Data Diskon</h3>
<a href="<?= base_url('/diskon/create') ?>">Tambah Diskon</a>
<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Nominal</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($diskon as $d): ?>
        <tr>
            <td><?= $d['tanggal'] ?></td>
            <td>Rp<?= number_format($d['nominal'], 0, ',', '.') ?></td>
            <td>
                <a href="<?= base_url('/diskon/edit/' . $d['id']) ?>">Edit</a> |
                <a href="<?= base_url('/diskon/delete/' . $d['id']) ?>" onclick="return confirm('Yakin?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach ?>
    </tbody>
</table>
