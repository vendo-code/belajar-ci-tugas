<?php $validation = session()->get('validation'); ?>
<h3><?= isset($diskon) ? 'Edit' : 'Tambah' ?> Diskon</h3>

<form action="<?= isset($diskon) ? base_url('/diskon/update/' . $diskon['id']) : base_url('/diskon/store') ?>" method="post">
    <label>Tanggal:</label>
    <input type="date" name="tanggal" value="<?= old('tanggal', $diskon['tanggal'] ?? '') ?>" <?= isset($diskon) ? 'readonly' : '' ?>>
    <br>

    <label>Nominal:</label>
    <input type="number" name="nominal" value="<?= old('nominal', $diskon['nominal'] ?? '') ?>">
    <br>

    <?php if ($validation): ?>
        <div style="color:red"><?= $validation->listErrors() ?></div>
    <?php endif; ?>

    <button type="submit">Simpan</button>
</form>
